﻿using FluentValidation;
using FluentValidation.AspNetCore;
using FluentValidation.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FluentValidationExample.Hooks
{
    public class ValidatorInterceptor : IValidatorInterceptor
    {
        private readonly ILogger<ValidatorInterceptor> _logger;

        public ValidatorInterceptor(ILogger<ValidatorInterceptor> logger)
        {
            _logger = logger;
        }
        public IValidationContext BeforeAspNetValidation(ActionContext actionContext, IValidationContext commonContext)
        {
            return commonContext;
        }

        public ValidationResult AfterAspNetValidation(ActionContext actionContext, IValidationContext validationContext,
            ValidationResult result)
        {
            _logger.LogWarning(
                $"Validation Error Count - {result.Errors.Count} for method {actionContext.ActionDescriptor.DisplayName}");
            return result;
        }
    }
}
